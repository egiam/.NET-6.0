create database BingoFinalDB

use BingoFinalDB

